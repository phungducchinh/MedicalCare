<?php
$connect = mysqli_connect("localhost","root","");

class response{
	function response($success,$msg,$data){
		$this->success = $success;
		$this->msg = $msg;
		$this->data = $data;
	}
}

if (!$connect) {
	$response["success"] = 0;
	$response["message"] = "Khong the ket noi toi server.";
	echo json_encode($response,JSON_UNESCAPED_UNICODE);
}else{
	mysqli_select_db($connect,"medicalcare");
	mysqli_set_charset($connect, 'UTF8');
}
?>
