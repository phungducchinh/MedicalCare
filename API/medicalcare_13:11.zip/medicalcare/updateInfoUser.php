<?php
include('register.php');
$requeren = array();
if ($_POST)
{
	$id = $_POST['id'];
	$name = $_POST["name"];
	$email = $_POST["email"];
	$password = $_POST["password"];
	$phone_number = $_POST["phone_number"];
	$birthday = $_POST["birthday"];
	$weight = $_POST["weight"];
	$height = $_POST["height"];
	$gender = $_POST["gender"];
	$address = $_POST["address"];
	$avatar = $_POST["avatar"];

	$query= " SELECT * from userinfo where userinfo.id = '$id'";
	$data = mysqli_query($connect,$query);
	if($data)
	{
		$qrUpdate = "UPDATE userinfo set userinfo.name = '$name' , userinfo.email = '$email' , userinfo.password = '$password', userinfo.phone_number = '$phone_number', userinfo.birthday = '$birthday', userinfo.weight = '$weight', userinfo.height = '$height', userinfo.gender = '$gender', userinfo.address = '$address', userinfo.avatar = '$avatar' Where userinfo.id ='$id'";
		$update = mysqli_query($connect,$qrUpdate);
		if ($update){
			$dataresponejson = new response(200,"Cập nhật thông tin hành công","");
			echo json_encode($dataresponejson,JSON_UNESCAPED_UNICODE);
		}else{
			$dataresponejson = new response(400,"Cập nhật thông tin tài khoản thất bại","");
			echo json_encode($dataresponejson,JSON_UNESCAPED_UNICODE);
		}
		
	}
	else
	{
			$dataresponejson = new response(400,"Tài khoản không tồn tại","");
			echo json_encode($dataresponejson,JSON_UNESCAPED_UNICODE);
	}

} 
?>