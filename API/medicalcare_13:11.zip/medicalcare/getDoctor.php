<?php
include('register.php');
$requeren = array();
if ($_GET)
{
	$hospital_id = $_GET['hospital_id'];
	$specialize_id = $_GET['specialize_id'];
	$certificate_id = $_GET['certificate_id'];
	$gender = $_GET['gender'];

	$qrHospital = "";
	$qrSpecialize = "";
	$qrCertificate = "";
	$qrGender = "";

	$specialize_name = '"specialize"';

	$query = "SELECT DISTINCT doctor.id, doctor.name, doctor.address, doctor.avatar, doctor.phone_number, doctor.info_about, doctor.type_time,specialize.name as  $specialize_name from doctor ";

	// -- $query= " SELECT * from doctor_hospital WHere doctor_hospital.hospital_id ='$hospital_id'";

	// check hospital id
	if (empty($hospital_id)){
		$qrHospital = "INNER JOIN doctor_hospital on doctor_hospital.doctor_id = doctor.id";
	}else{
		$qrHospital = "INNER JOIN doctor_hospital on doctor_hospital.doctor_id = doctor.id AND doctor_hospital.hospital_id = $hospital_id";
	}


	// check specialize ID

	if (empty($specialize_id)){
		$qrSpecialize = "INNER JOIN specialize on doctor.specialize_id = specialize.id ";
	}else{
		$qrSpecialize = "INNER JOIN specialize on doctor.specialize_id = specialize.id  and specialize.id = $specialize_id";
	}

	// check certificate ID

	if (empty($certificate_id)){
		$qrCertificate = "INNER JOIN doctor_certificate on doctor_certificate.doctor_id = doctor.id";
	}else{
		$qrCertificate = "INNER JOIN doctor_certificate on doctor_certificate.doctor_id = doctor.id  AND doctor_certificate.certificate_id = $certificate_id";
	}


	// check gender ID

	if (empty($gender)){
		$qrGender = "";
	}else{
		$qrGender = "AND doctor.gender = '$gender'";
	}

	$query = $query ." ". $qrHospital ." ". $qrSpecialize ." ". $qrCertificate ." ". $qrGender;

	// echo $query;
	$data = mysqli_query($connect,$query);

	if($data)
	{
		class certificate {
			function certificate($id, $name){
				$this->id = $id;
				$this->name = $name;
			}
		}
		class doctor
		{
			function doctor($id,$name,$specialize,$address,$phone_number,$info_about,$certificate,$type_time,$avatar)
			{
				$this->id=$id;
				$this->name=$name;
				$this->specialize = $specialize;
				$this->address = $address;
				$this->phone_number = $phone_number;
				$this->info_about = $info_about;
				$this->certificate = $certificate;
				$this->type_time = $type_time;
				$this->avatar = $avatar;
			}
		}	
		while ($row=mysqli_fetch_assoc($data)) 
		{
			$id = (int)$row["id"];
			$name = $row["name"];
			$specialize = $row["specialize"];
			$address = $row["address"];
			$phone_number = $row["phone_number"];
			$info_about = $row["info_about"];
			$type_time = (int)$row["type_time"];
			$avatar = $row["avatar"];

			$arrCertificate = array();
			$qrGetAllCertificate = "SELECT certificate.id, certificate.name from certificate , doctor_certificate WHere doctor_certificate.doctor_id = $id and doctor_certificate.certificate_id = certificate.id";

			$dataCertificate = mysqli_query($connect,$qrGetAllCertificate);

			if ($dataCertificate){
				while ($row=mysqli_fetch_assoc($dataCertificate)) {
					$idC = (int) $row["id"];
					$nameC = $row["name"];
					array_push($arrCertificate,new certificate($idC,$nameC));
				}
			}

			array_push($requeren,new doctor($id,$name,$specialize,$address,$phone_number,$info_about,$arrCertificate,$type_time,$avatar));
			
		}

		$dataresponejson = new response(200,"Thành công",$requeren);

		echo json_encode($dataresponejson,JSON_UNESCAPED_UNICODE);

	}
	else
	{
		$requeren = new response(400,"Không thể lấy thông tin bác sĩ","");
		echo json_encode($requeren,JSON_UNESCAPED_UNICODE);
	}

} 
?>