<?php
$con = mysqli_connect("databases-auth.000webhost.com","id6616300_sql3249233","Chinh18102003"," id6616300_sql3249233") or die ("không thể kết nối đến Mysql".mysql_error());
$con->set_charset("UTF8") or die ("Khong the kết nối đến database");

?>

