<?php
include('register.php');
$requeren = array();
if ($_GET)
{
	$id = $_GET['id'];
	$query= " SELECT * from hospital_specialize WHere hospital_specialize.hospital_id ='$id'";
	$data = mysqli_query($connect,$query);
	$num_rows = mysqli_num_rows($data);
	if ($data)//if($num_rows > 0)
	{
		class doctor
		{
			function doctor($id,$name)
			{
				$this->id=$id;
				$this->name=$name;
			}
		}	
		while ($row=mysqli_fetch_assoc($data)) 
		{
			$idquest=$row["specialize_id"];
			$qrDoctor = "SELECT specialize.id, specialize.name from specialize WHERE specialize.id = '$idquest'";

			$dataDoctor = mysqli_query($connect,$qrDoctor);
			$num = mysqli_num_rows($dataDoctor);
			if ($num > 0){
				while ($rowD = mysqli_fetch_assoc($dataDoctor)){
					$id = $rowD["id"];
					$name = $rowD["name"];
					array_push($requeren,new doctor($id,$name));
				}
			}
		}
		
        $info = json_encode($requeren,JSON_UNESCAPED_UNICODE);
        $dataresponejson = new response(200,"Thành công",$requeren);

        echo json_encode($dataresponejson,JSON_UNESCAPED_UNICODE);
			
	}
	else
	{
        $requeren = new response(400,"Không thể lấy thông tin chuyên khoa","");
        echo json_encode($requeren,JSON_UNESCAPED_UNICODE);
	}

} 
?>