<?php
include('register.php');
$requeren = array();
if ($_GET)
{
    $id = $_GET['id'];
    $query= "SELECT * from appointment where appointment.id= '$id'";
    $data = mysqli_query($connect,$query);
    // $num_rows = mysqli_num_rows($data);
    // if ($data){
    //  $dataresponejson = new response("200","Thành công",$requeren);

    //  echo json_encode($dataresponejson,JSON_UNESCAPED_UNICODE);

    // }else{
    //  {
    //      $requeren = new response("400","Không thể lấy dữ liệu","");
    //      echo json_encode($requeren,JSON_UNESCAPED_UNICODE); 
    //  }
    // }
    if(mysqli_num_rows($data) > 0)
    {
        class appointment
        {
            function appointment($id,$user_id,$doctor_id,$hospital_id,$dateBook,$timeBook,$problem,$fee,$status, $doctor)
            {
                $this->id =  (int)$id;
                $this->user_id = (int)$user_id;
                $this->doctor_id = (int)$doctor_id;
                $this->hospital_id = (int)$hospital_id;
                $this->dateBook = $dateBook;
                $this->timeBook = $timeBook;
                $this->problem = $problem;
                $this->fee = (int)$fee;
                $this->status = (int)$status;
                $this->doctor = $doctor;
            }
        }

        class doctorD{
            function doctorD($id,$doctor_name, $specialize,$hospital,$avatar){
                $this->id = (int)$id;
                $this->doctor_name = $doctor_name;
                $this->specialize = $specialize;
                $this->hospital = $hospital;
                $this->avatar = $avatar;
            }
        }

        while ($row=mysqli_fetch_assoc($data)) 
        {
            $id = $row["id"];
            $user_id = $row["user_id"];
            $doctor_id = $row["doctor_id"];
            $hospital_id = $row["hospital_id"];
            $dateBook = $row["dateBook"];
            $timeBook = $row["timeBook"];
            $problem = $row["problem"];
            $fee = $row["fee"];
            $status = $row["status"];

            $queryD= "SELECT * from doctor where doctor.id = '$doctor_id'";
            $dataDoctor = mysqli_query($connect,$queryD);

            while ($row=mysqli_fetch_assoc($dataDoctor)) 
            {
                $nameD = $row["name"];
                $specialize_id = $row["specialize_id"];
                $avatar = $row["avatar"];

                $qrSpecialize = "SELECT specialize.name from specialize where specialize.id = '$specialize_id'";
                $special = mysqli_query($connect,$qrSpecialize);

                $specialize = "";
                while ($rowD=mysqli_fetch_assoc($special)) 
                {
                    $specialize = $rowD["name"];
                }

                $qrHospital = "SELECT * from hospital where hospital.id = '$hospital_id '";
                $hospitalData = mysqli_query($connect,$qrHospital);

                $hospital = "";
                $address = "";
                while ($rowH=mysqli_fetch_assoc($hospitalData)) 
                {
                    $hospital = $rowH["name"];
                    $address = $rowH["address"];
                }

                $hospital_address = $hospital .", ". $address;

                $doctor_respone = new doctorD($doctor_id,$nameD,$specialize,$hospital_address,$avatar);
            }
            $requeren = new appointment($id,$user_id,$doctor_id,$hospital_id,$dateBook,$timeBook,$problem,$fee,$status,$doctor_respone);
        }
        $dataresponejson = new response(200,"Thành công",$requeren);

        echo json_encode($dataresponejson,JSON_UNESCAPED_UNICODE);
    }
    else
    {
        $requeren = new response("400","Không thể lấy thông tin cuộc hẹn","");
        echo json_encode($requeren,JSON_UNESCAPED_UNICODE); 
    }

} 
?>