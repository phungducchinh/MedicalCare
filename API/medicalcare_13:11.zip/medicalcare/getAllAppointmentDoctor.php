<?php
include('register.php');
$requeren = array();
if ($_GET)
{
	$doctor_id = $_GET['doctor_id'];
	$query= "SELECT * from appointment where appointment.doctor_id = '$doctor_id'";
	$data = mysqli_query($connect,$query);
	// $num_rows = mysqli_num_rows($data);
	// if ($data){
	// 	$dataresponejson = new response("200","Thành công",$requeren);

	// 	echo json_encode($dataresponejson,JSON_UNESCAPED_UNICODE);

	// }else{
	// 	{
	// 		$requeren = new response("400","Không thể lấy dữ liệu","");
	// 		echo json_encode($requeren,JSON_UNESCAPED_UNICODE);	
	// 	}
	// }
	if($data)
	{
		class appointment
		{
			function appointment($id,$user_id,$doctor_id,$hospital_id,$dateBook,$timeBook,$problem,$fee,$status, $doctor,$user_name)
			{
				$this->id =  (int)$id;
				$this->user_id = (int)$user_id;
				$this->doctor_id = (int)$doctor_id;
				$this->hospital_id = (int)$hospital_id;
				$this->dateBook = $dateBook;
				$this->timeBook = $timeBook;
				$this->problem = $problem;
				$this->fee = (int)$fee;
				$this->status = (int)$status;
				$this->doctor = $doctor;
				$this->user_name = $user_name;
			}
		}	

		class doctorD{
			function doctorD($id,$doctor_name, $specialize,$hospital){
				$this->id = (int)$id;
				$this->doctor_name = $doctor_name;
				$this->specialize = $specialize;
				$this->hospital = $hospital;
			}
		}

		while ($row=mysqli_fetch_assoc($data)) 
		{
			$id = $row["id"];
			$user_id = $row["user_id"];
			$doctor_id = $row["doctor_id"];
			$hospital_id = $row["hospital_id"];
			$dateBook = $row["dateBook"];
			$timeBook = $row["timeBook"];
			$problem = $row["problem"];
			$fee = $row["fee"];
			$status = $row["status"];

			$queryD= "SELECT * from doctor where doctor.id = '$doctor_id'";
			$dataDoctor = mysqli_query($connect,$queryD);

			while ($row=mysqli_fetch_assoc($dataDoctor)) 
			{
				$nameD = $row["name"];
				$specialize_id = $row["specialize_id"];

				$qrSpecialize = "SELECT specialize.name from specialize where specialize.id = '$specialize_id'";
				$special = mysqli_query($connect,$qrSpecialize);

				$specialize = "";
				while ($rowD=mysqli_fetch_assoc($special)) 
				{
					$specialize = $rowD["name"];
				}

				$qrHospital = "SELECT * from hospital where hospital.id = '$hospital_id '";
				$hospitalData = mysqli_query($connect,$qrHospital);

				$hospital = "";
				$address = "";
				while ($rowH=mysqli_fetch_assoc($hospitalData)) 
				{
					$hospital = $rowH["name"];
					$address = $rowH["address"];
				}

				$hospital_address = $hospital .", ". $address;
				$doctor_respone = new doctorD($doctor_id,$nameD,$specialize,$hospital_address);
			}

			$us_name = "";
			$qrUser = "SELECT * from userinfo where userinfo.id = '$user_id'";
			$dataUser = mysqli_query($connect,$qrUser);

			if ($dataUser){
				while ($rowU=mysqli_fetch_assoc($dataUser)) {
					$us_name = $rowU["name"];
				}
			}else{
				$us_name = "";
			}


			array_push($requeren,new appointment($id,$user_id,$doctor_id,$hospital_id,$dateBook,$timeBook,$problem,$fee,$status,$doctor_respone,$us_name));
		}
		$dataresponejson = new response(200,"Thành công",$requeren);

		echo json_encode($dataresponejson,JSON_UNESCAPED_UNICODE);

	}
	else
	{
		$requeren = new response(400,"Không thể lấy dữ liệu","");
		echo json_encode($requeren,JSON_UNESCAPED_UNICODE);	
	}

} 
?>