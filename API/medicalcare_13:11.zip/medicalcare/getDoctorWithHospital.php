<?php
include('register.php');
date_default_timezone_set('Asia/Ho_Chi_Minh');
$requeren = array();
if ($_GET)
{
	$id = $_GET['id'];
	$query= " SELECT * from doctor_hospital WHere doctor_hospital.hospital_id ='$id'";
	$data = mysqli_query($connect,$query);
	$num_rows = mysqli_num_rows($data);
	if($num_rows > 0)
	{
		class doctor
		{
			function doctor($id,$name,$type_time,$fee,$list_time)
			{
				$this->id= (int)$id;
				$this->name=$name;
				$this->type_time = (int)$type_time;
				$this->fee = (int)$fee;
				$this->list_time = $list_time;
			}
		}	
		while ($row=mysqli_fetch_assoc($data)) 
		{
			$idquest=$row["doctor_id"];
			$qrDoctor = "SELECT * from doctor WHERE doctor.id = '$idquest'";

			$dataDoctor = mysqli_query($connect,$qrDoctor);
			$num = mysqli_num_rows($dataDoctor);

			$arrDate = array();
			$now = date('d-m-Y');
			$date=date_create($now);
			$i = 1;
			while ($i < 8) {
				date_modify($date,"+1 days");
				$new = date_format($date,'d-m-Y');
			// $check = getdate($new);

				$number = date('l', strtotime($new));
			// echo $number;
				if ($number != "Sunday"){
					array_push($arrDate, $new);
				}
			// echo $check['weekday'];
				$i = $i + 1;
			}

			if ($num > 0){
				while ($rowD = mysqli_fetch_assoc($dataDoctor)){
					$id = $rowD["id"];
					$name = $rowD["name"];
					$type_time = $rowD["type_time"];
					$fee = $rowD["fee"];
					array_push($requeren,new doctor($id,$name,$type_time,$fee,$arrDate));
				}
			}
		}
		
		// $arrDate = array();
		// $now = date('d-m-Y');
		// $date=date_create($now);
		// $i = 1;
		// while ($i < 8) {
		// 	date_modify($date,"+1 days");
		// 	$new = date_format($date,'d-m-Y');
		// 	// $check = getdate($new);

		// 	$number = date('l', strtotime($new));
		// 	// echo $number;
		// 	if ($number != "Sunday"){
		// 		array_push($arrDate, $new);
		// 	}
		// 	// echo $check['weekday'];
		// 	$i = $i + 1;
		// }
		// date_modify($now,"+11 days");

		// array_push($arrDate, $now);
		// date_modify($date, "+11 days");
		// echo date_format($date, "d-m-Y");

		// $today = date("Y-m-d");
		// $number = date('l', strtotime($today));
		// echo "Today: " . $today . " weekday: " . $number . "<br>";

		// array_push($requeren, $arrDate);

		$dataresponejson = new response(200,"Thành công",$requeren);

		echo json_encode($dataresponejson,JSON_UNESCAPED_UNICODE);

	}
	else
	{
		$requeren = new response(400,"Không thể lấy thông tin bác sĩ","");
		echo json_encode($requeren,JSON_UNESCAPED_UNICODE);
	}

} 
?>