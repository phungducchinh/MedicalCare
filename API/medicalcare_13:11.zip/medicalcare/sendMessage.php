<?php
include('register.php');
$requeren = array();
if ($_POST)
{
	$user_id = $_POST['user_id'];
	$message = $_POST["message"];

	$query= " INSERT INTO message (user_id, message) VALUES ('$user_id', '$message')";
	$data = mysqli_query($connect,$query);
	if($data)
	{
		$dataresponejson = new response(200,"Cập nhật thông tin hành công","");
		echo json_encode($dataresponejson,JSON_UNESCAPED_UNICODE);
	}
	else
	{
		$dataresponejson = new response(400,"Không thể gửi tin nhắn!","");
		echo json_encode($dataresponejson,JSON_UNESCAPED_UNICODE);
	}

} 
?>