<?php

function sendMail($emailFirst,$nameFirst,$contentFirst,$emailSecond,$nameSecond,$contentSecond){
	require 'src/PHPMailer.php';

	$mail = new PHPMailer(true);                              // Passing `true` enables exceptions
	try {
    //Server settings
		$mail->CharSet = 'UTF-8';
    $mail->SMTPDebug = 0;                                 // Enable verbose debug output
    $mail->isSMTP();                                      // Set mailer to use SMTP
    $mail->Host = 'smtp.gmail.com';  // Specify main and backup SMTP servers
    $mail->SMTPAuth = true;                               // Enable SMTP authentication
    $mail->Username = 'madicalcare.pdc@gmail.com';                 // SMTP username
    $mail->Password = 'Chinh18102003';                           // SMTP password
    $mail->SMTPSecure = 'tls';                            // Enable TLS encryption, `ssl` also accepted
    $mail->Port = 587;                                    // TCP port to connect to

    //Recipients
    $mail->setFrom('madicalcare.pdc@gmail.com', 'Phần mềm sổ tay y tế');
    $mail->addAddress($emailFirst, $nameFirst);     // Add a recipient
    $mail->addReplyTo('madicalcare.pdc@gmail.com', 'Phần mềm sổ tay y tế');

    //Content
    $mail->isHTML(true);                                  // Set email format to HTML
    $mail->Subject = 'Thông báo từ Phần mềm Sổ tay y tế';
    $mail->Body    = $contentFirst;

    $mail->send();

    $mail->setFrom('madicalcare.pdc@gmail.com', 'Phần mềm sổ tay y tế');
    $mail->addAddress($emailSecond, $nameSecond);     // Add a recipient
    $mail->addReplyTo('madicalcare.pdc@gmail.com', 'Phần mềm sổ tay y tế');

    //Content
    $mail->isHTML(true);                                  // Set email format to HTML
    $mail->Subject = 'Thông báo từ Phần mềm Sổ tay y tế';
    $mail->Body    = $contentSecond;

    $mail->send();

    return true;
} catch (Exception $e) {
	return false;
}
}
?>