<?php
include('register.php');
$requeren = array();
if ($_GET)
{
	$user_id = $_GET['user_id'];
	$query= " SELECT * from appointment where appointment.user_id = '$user_id'";
	$data = mysqli_query($connect,$query);
	$num_rows = mysqli_num_rows($data);
	if($num_rows > 0)
	{
		class appointment
		{
			function appointment($id,$user_id,$doctor_id,$hospital_id,$dateBook,$timeBook,$problem,$fee)
			{
				$this->success=$success;
				$this->id=$id;
				$this->user_id = $user_id;
				$this->doctor_id = $doctor_id;
				$this->hospital_id=$hospital_id;
				$this->dateBook=$dateBook;
				$this->timeBook = $timeBook;
				$this->problem = $problem;
				$this->fee = $fee;
			}
		}	
		while ($row=mysqli_fetch_assoc($data)) 
		{
			$success=1;
			$id = $row["id"];
			$user_id = $row["user_id"];
			$doctor_id = $row["doctor_id"];
			$hospital_id = $row["hospital_id"];
			$dateBook = $row["dateBook"];
			$timeBook = $row["timeBook"];
			$problem = $row["problem"];
			$fee = $row["fee"];
			array_push($requeren,new appointment($success,$id,$user_id,$doctor_id,$hospital_id,$dateBook,$timeBook,$problem,$fee));
		}
			echo json_encode($requeren,JSON_UNESCAPED_UNICODE);
			
	}
	else
	{
		$requeren["success"]=0;
		echo json_encode($requeren,JSON_UNESCAPED_UNICODE);	
	}

} 
?>