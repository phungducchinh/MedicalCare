<?php
include('register.php');
$requeren = array();
if ($_GET)
{
	$email = $_GET['email'];
	$query= "SELECT * From userinfo where userinfo.email = '$email'";
	$data = mysqli_query($connect,$query);
	$num_rows = mysqli_num_rows($data);

	if (mysqli_num_rows($data) > 0){
			
		class detail
		{
			function detail($id,$name,$email,$password,$phone_number, $birthday, $weight, $height, 
				$gender, $doctor_id, $address, $avatar)
			{
				$this->id = $id;
				$this->name = $name;//hiện thị ngoài json
				$this->email = $email;
				$this->password = $password;
				$this->phone_number = $phone_number;
				$this->birthday = $birthday;
				$this->weight = $weight;
				$this->height = $height;
				$this->gender = $gender;
				$this->doctor_id = $doctor_id;
				$this->address = $address;
				$this->avatar = $avatar;
			}
		}
		while ($row=mysqli_fetch_assoc($data)) 
		{
			$id = (int)$row["id"];
			$name = $row["name"];
			$email = $row["email"];
			$password = $row["password"];
			$phone_number = $row["phone_number"];
			$birthday = $row["birthday"];
			$weight = (int)$row["weight"];
			$height = (int)$row["height"];
			$gender = $row["gender"];
			$address = $row["address"];
			$avatar = $row["avatar"];

			$qrDoctor = "SELECT user_doctor.doctor_id from user_doctor where user_doctor.user_id = '$id'";
			$dataDoctor = mysqli_query($connect,$qrDoctor);
			$idDoctor = "";
			if ($dataDoctor ){
				while ($rowD = mysqli_fetch_assoc($dataDoctor)){
					$idDoctor = (int)$rowD["doctor_id"];
				}
			}

			if (empty($idDoctor)){
				$idDoctor = 0;
			}

			// array_push($requeren,new detail($id,$name,$email,$password,$phone_number,$birthday, $weight, $height,$gender,$idDoctor,$address,$avatar));

			$detail = new detail($id,$name,$email,$password,$phone_number,$birthday, $weight, $height,$gender,$idDoctor,$address,$avatar);
		}
			$info = json_encode($requeren,JSON_UNESCAPED_UNICODE);
			$dataresponejson = new response(200,"Thành công",$detail);

			echo json_encode($dataresponejson,JSON_UNESCAPED_UNICODE);
			
	}
	else
	{
		$requeren = new response(400,"Không thể lấy dữ liệu","");
		echo json_encode($requeren,JSON_UNESCAPED_UNICODE);	
	}

} 
?>