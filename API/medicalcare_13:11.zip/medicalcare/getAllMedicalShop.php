<?php
include('register.php');
$requeren = array();
if ($_GET)
{
	$idquest = $_GET['idquest'];
	$query= "SELECT * from medical_shop";
	$data = mysqli_query($connect,$query);
	$num_rows = mysqli_num_rows($data);
	if($num_rows > 0)
	{
		class hospital
		{
			function hospital($id,$name,$address,$phone_number,$info,$avatar)
			{
				$this->id=(int)$id;
				$this->name = $name;
				$this->address = $address;
				$this->phone_number=$phone_number;
				$this->info = $info;
				$this->avatar = $avatar;
			}
		}	
		while ($row=mysqli_fetch_assoc($data)) 
		{
			$id = $row["id"];
			$name = $row["name"];
			$address = $row["address"];
			$phone_number = $row["phone_number"];
			$info = $row["info"];
			$avatar = $row["avatar"];
			array_push($requeren,new hospital($id,$name,$address,$phone_number,$info,$avatar));
		}
			$info = json_encode($requeren,JSON_UNESCAPED_UNICODE);
			$dataresponejson = new response(200,"Thành công",$requeren);
			echo json_encode($dataresponejson,JSON_UNESCAPED_UNICODE);
	}
	else
	{
		$requeren = new response(400,"Không thể lấy dữ liệu","");
		echo json_encode($requeren,JSON_UNESCAPED_UNICODE);	
	}

} 
?>