<?php
require 'ConnectMysql.php'; 
if ($_GET) {
	$iduser =$_GET['iduser'];
	$Name = $_GET['Name'];
	$Username = $_GET['Username'];
	$Password = $_GET['Password'];
	$Phonenumber = $_GET['Phonenumber'];
	$Email = $_GET['Email'];
	$Type = $_GET['Type'];
	$test = 'SELECT Username from User where Username = "'.$username.'" '; 
	//$test = “SELECT Username FROM User WHERE Username = '".$Username.”’  ”;

		$query1 = mysqli_query($con,$test);
		$num_rows = mysqli_num_rows($query1);
		if ($num_rows==0)
		{
			//$sql = "INSERT INTO User(iduser, Name, Username,Phonenumber, Email, Password, Type) VALUES ($iduser,'$Name','$Username’,’$Phonenumber’,’$Email',$Password,$Type)";
			$sql = "INSERT INTO User(iduser, Name, Username,Phonenumber, Email, Password, Type) VALUES ($iduser,’$Name','$Username’,’$Phonenumber’,’$Email',$Password,$Type)";

			$query = mysqli_query($con,$sql);			
			if($query)
			{
				$response["success"] = 1;
				$response["message"] = "Tài khoản đã được tạo.";
				echo json_encode($response,JSON_UNESCAPED_UNICODE);
			}
			else
			{
				$response["success"] = 0;
				$response["message"] = "Mã id bị trùng!";
				echo json_encode($response,JSON_UNESCAPED_UNICODE); 
			}
		}	
		else
			{
				$response["success"] = 0;
				$response["message"] = "username Đã Tồn Tại";
				echo json_encode($response,JSON_UNESCAPED_UNICODE);
			}
}
else
{
				$response["success"] = 0;
				echo json_encode($response,JSON_UNESCAPED_UNICODE);
}
?>
