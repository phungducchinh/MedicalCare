<?php
require 'register.php'; 
if ($_POST) {
	
	// $name = $_GET['name'];
	// $username = $_GET['username'];
	// $password = $_GET['password'];
	// $phoneNumber = $_GET['phoneNumber'];
	// $email = $_GET['email'];
	// $Type = $_GET['Type']; 

	$name = $_POST["name"];
	$email = $_POST["email"];
	$password = $_POST["password"];
	$phone_number = $_POST["phone_number"];
	$birthday = $_POST["birthday"];
	$weight = $_POST["weight"];
	$height = $_POST["height"];
	$gender = $_POST["gender"];
	$address = $_POST["address"];
	$avatar = $_POST["avatar"];
	
	$test = "SELECT * from userinfo where userinfo.email = '$email'";
	$query1 = mysqli_query($connect,$test);
	if ((mysqli_num_rows($query1)) > 0){
			$dataresponejson = new response(400,"Tài khoản đã tồn tại","");
			echo json_encode($dataresponejson,JSON_UNESCAPED_UNICODE);
	}else{
		$sql ="INSERT INTO userinfo (name, email, password, phone_number, birthday, weight, height, gender, address,avatar) VALUES ('$name', '$email',  '$password', '$phone_number', '$birthday', '$weight','$height','$gender','$address','$avatar')";
		$query = mysqli_query($connect,$sql); 
		if($query){
			$dataresponejson = new response(200,"Thành công","");
			echo json_encode($dataresponejson,JSON_UNESCAPED_UNICODE);
		}else{
			$dataresponejson = new response(400,"Đăng ký tài khoản thất bại","");
			echo json_encode($dataresponejson,JSON_UNESCAPED_UNICODE);
		}
	}
	
		
}		
?>
