<?php
include('register.php');
$requeren = array();
if ($_GET)
{
    class info{
        function info($benhvien,$chuyenkhoa,$hocham,$gioitinh){
            $this->benhvien = $benhvien;
            $this->chuyenkhoa = $chuyenkhoa;
            $this->hocham = $hocham;
            $this->gioitinh = $gioitinh;
        }
    }

    $id = $_GET['id'];
    class dataResponse{
        function dataResponse($id, $name){
            $this->id = (int)$id;
            $this->name = $name;
        }
    }

// querry get all hospital
    $arrHospital = array();
    $qrHospital = "SELECT * from hospital";
    $dataHospital = mysqli_query($connect,$qrHospital);

    if (mysqli_num_rows($dataHospital) > 0){
        while ($row = mysqli_fetch_assoc($dataHospital)) {
            $id = $row["id"];
            $name = $row["name"];
            array_push($arrHospital, new dataResponse($id,$name));
        }
    }
// querry get all specialize
    $arrSpecialize= array();
    $qrSpecialize = "SELECT specialize.id, specialize.name from specialize";
    $dataSpecialize = mysqli_query($connect,$qrSpecialize);

    if (mysqli_num_rows($dataSpecialize) > 0){
        while ($row = mysqli_fetch_assoc($dataSpecialize)) {
            $id = $row["id"];
            $name = $row["name"];
            array_push($arrSpecialize, new dataResponse($id,$name));
        }
    }

// querry get all certificate

    $arrCertificate = array();
    $qrCertificate = "SELECT certificate.id, certificate.name from certificate";
    $dataCertificate = mysqli_query($connect,$qrCertificate);

    if (mysqli_num_rows($dataCertificate) > 0){
        while ($row = mysqli_fetch_assoc($dataCertificate)) {
            $id = $row["id"];
            $name = $row["name"];
            array_push($arrCertificate, new dataResponse($id,$name));
        }
    }


    $arrGender = array();
    array_push($arrGender, new dataResponse(0,"Nam"));
    array_push($arrGender, new dataResponse(1,"Nữ"));

    // array_push($requeren, new info($arrHospital,$arrSpecialize,$arrCertificate,$arrGender));
    $info = new info($arrHospital,$arrSpecialize,$arrCertificate,$arrGender);


    $dataresponejson = new response(200,"Thành công",$info);

    echo json_encode($dataresponejson,JSON_UNESCAPED_UNICODE);

        // $requeren = new response("400","Không thể lấy thông tin cuộc hẹn","");
        // echo json_encode($requeren,JSON_UNESCAPED_UNICODE); 


} 
?>