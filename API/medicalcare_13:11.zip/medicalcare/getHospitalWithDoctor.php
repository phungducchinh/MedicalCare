<?php
include('register.php');
$requeren = array();
if ($_GET)
{
	$idDoctor = $_GET['idquest'];
	$query= "SELECT hospital.id, hospital.name, hospital.address, hospital.phone_number FROM hospital, doctor_hospital WHERE doctor_hospital.hospital_id = hospital.id AND doctor_hospital.doctor_id = $idDoctor";
	$data = mysqli_query($connect,$query);
	if($data)
	{
		class hospital
		{
			function hospital($id,$name,$address,$phone_number)
			{
				$this->id= (int)$id;
				$this->name = $name;
				$this->address = $address;
				$this->phone_number=$phone_number;
			}
		}	

		while ($row=mysqli_fetch_assoc($data)) 
		{
			$id = $row["id"];
			$name = $row["name"];
			$address = $row["address"];
			$phone_number = $row["phone_number"];
			array_push($requeren,new hospital($id,$name,$address,$phone_number));
		}
		$info = json_encode($requeren,JSON_UNESCAPED_UNICODE);
		$dataresponejson = new response(200,"Thành công",$requeren);
		echo json_encode($dataresponejson,JSON_UNESCAPED_UNICODE);
		
	}
	else
	{
		$requeren = new response(400,"Không thể lấy dữ liệu","");
		echo json_encode($requeren,JSON_UNESCAPED_UNICODE);	
	}

} 
?>