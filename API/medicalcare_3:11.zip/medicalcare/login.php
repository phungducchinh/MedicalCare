<?php
require 'register.php'; 
if ($_GET) {
	$email = $_GET["email"];
	$password = $_GET["password"];
	$sql = "SELECT * from userinfo where userinfo.email =  '$email' AND userinfo.password = '$password'";
	$data = mysqli_query($connect,$sql);
	if(mysqli_num_rows($data) > 0)
	{
		$dataresponejson = new response(200,"Đănh nhập thành công","");
		echo json_encode($dataresponejson,JSON_UNESCAPED_UNICODE);
		
	}
	else
	{
		$dataresponejson = new response("400","Tài khoản không tồn tại.","");
		echo json_encode($dataresponejson,JSON_UNESCAPED_UNICODE);
	}  

}
else
{
	$dataresponejson = new response("400","Đăng nhập không thành công.","");
	echo json_encode($dataresponejson,JSON_UNESCAPED_UNICODE);
}  
?>

