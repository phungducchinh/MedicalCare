<?php
include('register.php');
$requeren = array();

if ($_GET)
{
	$idquest = $_GET['idquest'];
	$query= "SELECT * from emergency";
	$data = mysqli_query($connect,$query);
	$num_rows = mysqli_num_rows($data);
	if($num_rows > 0)
	{
		class emergency
		{
			function emergency($id,$name,$hospital_id,$phone_number)
			{
				$this->id= (int)$id;
				$this->name = $name;
				$this->hospital_id = (int)$hospital_id;
				$this->phone_number=$phone_number;
			}
		}	



		while ($row=mysqli_fetch_assoc($data)) 
		{
			$id = $row["id"];
			$name = $row["name"];
			$hospital_id = $row["hospital_id"];
			$phone_number = $row["phone_number"];
			array_push($requeren,new emergency($id,$name,$hospital_id,$phone_number));
		}
			$info = json_encode($requeren,JSON_UNESCAPED_UNICODE);
			$dataresponejson = new response(200,"Thành công",$requeren);
			echo json_encode($dataresponejson,JSON_UNESCAPED_UNICODE);
	}
	else
	{
		$requeren = new response(400,"Không thể lấy dữ liệu","");
		echo json_encode($requeren,JSON_UNESCAPED_UNICODE);	
	}

} 
?>