<?php
include ('register.php');
require 'PHPMailer/mailer.php';


if ($_GET) 
{
	$mang=array();
	$idAppointment = $_GET['idAppointment'];
	$user_id = $_GET['user_id'];
	$doctor_id = $_GET['doctor_id'];
	$test = "SELECT * from appointment where appointment.id = '$idAppointment'";
	$query1 = mysqli_query($connect,$test);

	if ((mysqli_num_rows($query1)) > 0){
		if($idAppointment!=null){
			$data="UPDATE appointment set appointment.status = '1'  Where appointment.id ='$idAppointment'";

			if(mysqli_query($connect,$data))
			{

				$queryEmailDoctor = "SELECT userinfo.email, userinfo.name from userinfo, user_doctor WHERE user_doctor.user_id = userinfo.id and user_doctor.doctor_id = '$doctor_id'";

				$emailDoctor = mysqli_query($connect,$queryEmailDoctor);


				$qrEmailUser = "SELECT userinfo.email , userinfo.name from userinfo where userinfo.id = '$user_id'";
				$user = mysqli_query($connect,$qrEmailUser);	


				if ($emailDoctor && $user) {

					while ($row=mysqli_fetch_assoc($user)) {
						$user_email = $row["email"];
						$user_name =  $row["name"];
					}

					while ($row=mysqli_fetch_assoc($emailDoctor)) {
						$doctor_email = $row["email"];
						$doctor_name =  $row["name"];
					}

					if (empty($doctor_name)){
						$doctor_name = "Bác sĩ chưa đăng ký thông tài khoản";
					}

					if(empty($doctor_email)){
						$doctor_email = "madicalcare.pdc@gmail.com";
					}

					$contentUser = "Bạn đã huỷ lịch hẹn thành công.<br>Bạn có thể vào phần quản lý lịch hẹn của để kiểm tra thông tin.<br>Xin cảm ơn!";
					$contentDoctor = "Cuộc hẹn với bện nhân '$user_name'đã bị huỷ.<br>Vui lòng vào quản lý lịch hẹn để kiểm tra lịch hẹn.<br>Xin cảm ơn!";

					sendMail($user_email,$user_name,$contentUser,$doctor_email,$doctor_name,$contentDoctor);

					$dataresponejson = new response(200,"Huỷ lịch hẹn thành công.","");
					echo json_encode($dataresponejson,JSON_UNESCAPED_UNICODE);
				}else{
					$requeren = new response(400,"Không thể gửi thông tin đến email.","");
					echo json_encode($requeren,JSON_UNESCAPED_UNICODE);	
				}
			}
			else
			{
				$requeren = new response(400,"Huỷ lịch hẹn thất bại","");
				echo json_encode($requeren,JSON_UNESCAPED_UNICODE);
			}
		}
	}else{
		$requeren = new response("400","Không có lịch hẹn.","");
		echo json_encode($requeren,JSON_UNESCAPED_UNICODE);

	}



}

?>