<?php
require 'register.php'; 
require 'PHPMailer/mailer.php';
if ($_POST) {

	$user_id = $_POST["user_id"];
	$doctor_id = $_POST["doctor_id"];
	$hospital_id = $_POST["hospital_id"];
	$dateBook = $_POST["dateBook"];
	$timeBook = $_POST["timeBook"];
	$problem = $_POST["problem"];
	$fee = $_POST["fee"];
	
	$test = "SELECT * from appointment where appointment.dateBook = '$dateBook' AND appointment.timeBook = '$timeBook' AND appointment.doctor_id = '$doctor_id' AND appointment.hospital_id = '$hospital_id'";
	$query1 = mysqli_query($connect,$test);
	if ((mysqli_num_rows($query1)) > 0){
		$requeren = new response(400,"Lịch hẹn đã tồn tại","");
		echo json_encode($requeren,JSON_UNESCAPED_UNICODE);	
	}else{
		$sql ="INSERT INTO appointment (user_id, doctor_id, hospital_id, dateBook , timeBook, problem, fee, status) VALUES ('$user_id', '$doctor_id','$hospital_id',  '$dateBook', '$timeBook', '$problem', '$fee' ,'0')";
		$query = mysqli_query($connect,$sql);
		if($query){

			$queryID = "SELECT appointment.id from appointment where appointment.user_id = '$user_id' AND appointment.dateBook = '$dateBook' AND appointment.timeBook = '$timeBook' ";
			$id = mysqli_query($connect,$queryID);

			$queryEmailDoctor = "SELECT userinfo.email, userinfo.name from userinfo, user_doctor WHERE user_doctor.user_id = userinfo.id and user_doctor.doctor_id = '$doctor_id'";

			$emailDoctor = mysqli_query($connect,$queryEmailDoctor);


			$qrEmailUser = "SELECT userinfo.email , userinfo.name from userinfo where userinfo.id = '$user_id'";
			$user = mysqli_query($connect,$qrEmailUser);	
				
			if ($id && $emailDoctor && $user) {
				$rowID = mysqli_fetch_assoc($id)["id"];

				while ($row=mysqli_fetch_assoc($user)) {
					$user_email = $row["email"];
					$user_name =  $row["name"];
				}

				while ($row=mysqli_fetch_assoc($emailDoctor)) {
					$doctor_email = $row["email"];
					$doctor_name =  $row["name"];
				}

				if (empty($doctor_name)){
					$doctor_name = "Bác sĩ chưa đăng ký thông tài khoản";
				}

				if(empty($doctor_email)){
					$doctor_email = "madicalcare.pdc@gmail.com";
				}

				$contentUser = "Bạn đã đăng ký lịch hẹn thành công.<br>Mã đặt lịch hẹn của bạn là " ." " . $rowID ." ". ".<br>Vui lòng có mặt trước 15 phút để chuẩn bị.<br>Bạn có thể vào phần quản lý lịch hẹn của để kiểm tra thông tin.<br>Xin cảm ơn!";
				$contentDoctor = "Bạn có một cuộc hẹn mới với bện nhân '$user_name' vào lúc '$timeBook' ngày '$dateBook'.<br>Vui lòng vào quản lý lịch hẹn để kiểm tra lịch hẹn.<br>Xin cảm ơn!";

				sendMail($user_email,$user_name,$contentUser,$doctor_email,$doctor_name,$contentDoctor);

				$dataresponejson = new response(200,"Đăng kí lịch hẹn thành công.",(int)$rowID);
				echo json_encode($dataresponejson,JSON_UNESCAPED_UNICODE);
			}else{
				$requeren = new response(400,"Không thể gửi thông tin đến email.","");
				echo json_encode($requeren,JSON_UNESCAPED_UNICODE);	
			}

		}else{
			$requeren = new response(400,"Đăng ký lịch hẹn thất bại","");
			echo json_encode($requeren,JSON_UNESCAPED_UNICODE);	
		}
	}
	
	
}		
?>
