<?php
include ('register.php');

if ($_GET) 
{
	$doctor_id = $_GET['doctor_id'];
	$hospital_id = $_GET['hospital_id'];
	$query= "SELECT * from doctor where doctor.id = '$doctor_id'";
	$data = mysqli_query($connect,$query);

	if($data){
		class doctorD{
			function doctorD($id,$doctor_name, $specialize,$hospital,$avatar){
				$this->id = (int)$id;
				$this->doctor_name = $doctor_name;
				$this->specialize = $specialize;
				$this->hospital = $hospital;
				$this->avatar = $avatar;
			}
		}

		while ($row=mysqli_fetch_assoc($data)) 
		{
			$nameD = $row["name"];
			$specialize_id = $row["specialize_id"];
			$avatar = $row["avatar"];

			$qrSpecialize = "SELECT specialize.name from specialize where specialize.id = '$specialize_id'";
			$special = mysqli_query($connect,$qrSpecialize);

			$specialize = "";
			while ($rowD=mysqli_fetch_assoc($special)) 
			{
				$specialize = $rowD["name"];
			}

			$qrHospital = "SELECT * from hospital where hospital.id = '$hospital_id '";
			$hospitalData = mysqli_query($connect,$qrHospital);

			$hospital = "";
			$address = "";
			while ($rowH=mysqli_fetch_assoc($hospitalData)) 
			{
				$hospital = $rowH["name"];
				$address = $rowH["address"];
			}

			$hospital_address = $hospital .", ". $address;

			$requeren = new doctorD($doctor_id,$nameD,$specialize,$hospital_address,$avatar);


			$dataresponejson = new response(200,"Thành công",$requeren);

			echo json_encode($dataresponejson,JSON_UNESCAPED_UNICODE);
		}
	}else{
		$requeren = new response(400,"Không thể lấy dữ liệu","");
		echo json_encode($requeren,JSON_UNESCAPED_UNICODE);	
	}
}

?>